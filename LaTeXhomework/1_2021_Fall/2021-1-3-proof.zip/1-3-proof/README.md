# README.md

## OLD
- UD第5章问题 21、24
- UD第18章问题 11、15、20、22、24、25
- ES第24节练习 4、6、8

# NEW
- UD第5章问题 12、24
- UD第18章问题 20、26; +prime problem
- ES第24节练习 4、6、7

- 选做题:
  - Numbers

- OT:
  - `Induction.v` in Coq
  - Double Counting
