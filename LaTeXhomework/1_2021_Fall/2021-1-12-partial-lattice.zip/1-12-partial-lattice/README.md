# README.md

## Homework

### OLD
- SM 第14章 32、44、46、58、62 (修改为only one isomorphic mapping)、66、70、75

### NEW
- SM 第14章 44、58、62 (修改为 only one isomorphic mapping)、71、72、75

- 选做题:
  - 2017级问题求解(一)期末试卷 题目 5

## OT

### OLD
- 序数
- 分配格充要条件

### NEW
- Dilworth's Theorem
- Lattice of Stable Matchings
