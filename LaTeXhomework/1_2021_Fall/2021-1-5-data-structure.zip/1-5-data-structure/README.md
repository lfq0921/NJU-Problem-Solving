# README.md

## OLD
- DH第2章练习 10、11、12、13、14、15、16

# NEW
- DH第2章练习 11、12 (a: III; b; c)、13、14 (b; c)、16

- 选做题:
  - Stackable Permutations of An

- OT:
  - Pointers and Arrays
  - Sequential Containers in C++ STL
