# README.md

## Homework

### OLD
- UD 第14章问题 3、5、6、21、23
- UD 第15章问题 10、14、15、17
- UD 第16章问题 6、7、14、15、16、17、18
- UD 第17章问题 21、22、23、24

### NEW
- UD 第14章问题 3 (b, d, g)、5、23
- UD 第15章问题 10 (f, g, h)、14、15
- UD 第16章问题 6、14、17、22
- UD 第17章问题 22、23

- 选做题:
  - 3.30 of "Elements of Set Theory"

## OT

### OLD
- bijection

### NEW
- Lambda Calculus
- Recursive Functions
