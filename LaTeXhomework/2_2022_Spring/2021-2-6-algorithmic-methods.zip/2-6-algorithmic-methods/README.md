# README.md

## Homework

### OLD
- DH 第 4 章练习 1, 8, 9, 12, 14

### NEW
- DH 第 4 章练习 8, 9, 12, 13

### Additional
- Closest-pair Problem (DH 4-10)

## OT

### OLD
- Alpha-Beta 剪枝
- SAT 求解算法

### NEW
- Alpha-Beta 剪枝
- SAT 求解算法