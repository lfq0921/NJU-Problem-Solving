# README.md

## Homework

### OLD
- TC 第 12.1 节练习 2、5
- TC 第 12.2 节练习 5、9
- TC 第 12.3 节练习 5

### NEW
- TC 12.1-5
- TC 12.2-9
- TC 12.3-5

### Additional

## OT

### OLD
- Splay tree
- 中序遍历的正确性

### NEW
- Splay tree
(建议: 调整到 Red-Black Tree 章节)