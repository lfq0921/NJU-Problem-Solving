# README.md

## Homework

### OLD
- TC 练习 18.1.1, 18.1.4
- TC 练习 18.2.3, 18.2.4
- TC 练习 18.3.1

### NEW
- TC 18.1-1, TC 18.1-4
- TC 18.2-3
- TC 18.3-1

### Additional
- TC 18.2-4

## OT

### OLD
- B 树插入算法对高度的影响
- 介绍 B* 树

### NEW
- 2-3 tree & 2-3-4 tree
  - \red{建议: 这个OT题目过于简单; 需要找新的题目替换。}