# README.md

## Homework

### OLD
- TC 第七章:
  - Exercises: 7.1-3, 7.2-4, 7.3-2, 7.4-2
  - Problem: 7-5
- TC 第八章:
  - Exercises: 8.1-4, 8.2-4, 8.3-4, 8.4-2
  - Problem: 8-2
- TC 第九章
  - Exercises: 9.1-1, 9.3-7

### NEW
- TC 7.2-2, 7.3-2, 7.4-2
- TC 8.1-4, 8.2-4, 8.3-4, Problem 8-2
- TC 9.1-1, 9.3-7

### Additional
- TC Problem 7-5

## OT

### OLD
- TC Problem 7.4
- Random-Selection 算法的平均情况时间复杂度

### NEW
- Analysis of Quicksort
- Sorting algorithms