# README.md

## Homework

### OLD
- CS 第 5.5 节问题 8、14
- TC 第 11.2 节练习 3、6
- TC 第 11.3 节练习 3、4
- TC 第 11.4 节练习 2、3
- TC 第 11 章问题 1、2

### NEW
- CS 5.5-8 (a, b, c)
- TC 11.2-3
- TC 11.3-3
- TC 11.4-3
- TC Problem 11-1、Problem 11-2

### Additional
- TC 11.2-6

## OT

### OLD
- Universal Hashing
- Hashing 故事

### NEW
- Perfect Hashing
- Bloom filter