# README.md

## Homework

### OLD
- TC 第 4.1 节练习 5
- TC 第 4.3 节练习 3
- TC 第 4.4 节练习 2
- TC 第 4.5 节练习 3
- TC 第 4 章问题 4

### NEW
- TC 4.1-5
- TC 4.3-3
- TC 4.4-5
- TC 4.5-4
- TC Problem 4-1
- TC Problem 4-3 (Except f and j)

### Additional
- TC Problem 4-3 (f and j)

## OT

### OLD
- 证明 The Master Theorem
- 介绍 Akra–Bazzi Method

### NEW
- 介绍 Akra–Bazzi Method
- 深入分析 MergeSort