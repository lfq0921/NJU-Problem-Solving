# README.md

## Homework

### OLD
- CS 1.1 节 13
- CS 1.2 节 5, 15
- CS 1.5 节 4, 12, 14

### NEW
- CS 1.2 节 1, 5, 6, 15
- CS 1.5 节 4, 12

### Additional
- 算法计数题目

## OT

### OLD
- The twelvefold way (1)
- The twelvefold way (2)

### NEW
- Sums?
- Binomial Coefficients?