# README.md

## Homework

### OLD
- TC 第 6.1 节练习 2、4、7
- TC 第 6.2 节练习 2、5、6
- TC 第 6.3 节练习 3
- TC 第 6.4 节练习 2、4
- TC 第 6.5 节练习 5、7、9

### NEW
- TC 6.1-2、6.1-7
- TC 6.2-5、6.2-6
- TC 6.3-3
- TC 6.4-2、6.4-4、6.4-5
- TC 6.5-5、6.5-9

### Additional
- Heap Equality

## OT

### OLD
- Heapsort vs. Quicksort 性能
- Binary tree => Heap => Priority queue

### NEW
- Binomial Heaps
- Fibonacci Heaps