# README.md

## Homework

### OLD
- CS 第4.1节问题 16, 17
- CS 第4.2节问题 8, 11
- CS 第4.3节问题 9
- CS 第4.4节问题 1, 6
- CS 第4.5节问题 8, 9, 10

### NEW
- CS 第4.1节问题 16
- CS 第4.2节问题 11
- CS 第4.3节问题 9(c), 18 
- CS 第4.5节问题 8, 10

### Additional
- a_n = 2a_{n-1} + a_{n-2} - 2a_{n-3} for n > 3

## OT

### OLD
- Josephus Problem
- Generating Function

### NEW
- Josephus Problem
- Generating Function