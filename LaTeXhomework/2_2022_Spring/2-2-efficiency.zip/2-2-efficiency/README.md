# README.md

## Homework

### OLD
- DH 第6章练习 1, 8, 10, 13, 18

### NEW
- DH 第6章练习 18, 19, 20 (a)
- TC 3.1-6, 3.1-7, Problem 3-3 (a; Try Your Best)

### Additional
- DH 第6章练习 13

## OT

### OLD
- Algorithmic Gap
- Asymptotic Notations

### NEW
- Decision Tree
- Aderversary Argument