# README.md

## Homework

### OLD
- CS 第 5.1 节问题 10, 12
- CS 第 5.2 节问题 4, 10
- CS 第 5.3 节问题 2, 6, 12
- CS 第 5.4 节问题 4, 10, 12 ("Solve Problem 10" 改为 "Solve Problem 11"), 15

### NEW
- CS 第 5.1 节问题 10, 12
- CS 第 5.2 节问题 4, 10
- CS 第 5.3 节问题 2, 12
- CS 第 5.4 节问题 10, 15

### Additional
- The Ballot Problem (Example 3.27 of Ross)

## OT

### OLD
- Monty Hall Problem
- TC Problem 5.2: Searching an unsorted array

### NEW
- Monty Hall Problem
- Shuffling cards ("Proofs from THE Book")