# README.md

## Homework

### OLD
- DH 第5章练习 6, 9, 10, 12
- 证明 Euclid (欧几里德) 算法的部分正确性

### NEW
- DH 第5章练习 8, 9, 10, 12, 14
- 证明 Euclid (欧几里德) 算法的部分正确性

## OT

### OLD
- Insertion Sort 的正确性
- Cyclic Hanoi Problem 算法的正确性证明

### NEW
- Insertion Sort 的正确性 (推荐使用 Dafny)
- Cyclic Hanoi Problem 算法的正确性证明
