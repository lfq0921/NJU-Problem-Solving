# README.md

## Homework

### OLD
- MA 2.6 (只要求考察 Push 操作)
- TC 第 10.1 节练习 4、5、6
- TC 第 10.2 节练习 1、2、3、6
- TC 第 10.3 节练习 4、5
- TC 第 10.4 节练习 2、3、4
- TC 第 10 章问题 3

### NEW
- MA 2.6 (只要求考察 Push 操作)
- TC 第 10.1 节练习 4、6
- TC 第 10.2 节练习 6
- TC 第 10.3 节练习 4、5
- TC 第 10.4 节练习 2、3
- TC 第 10 章问题 3

### Additional
- TC 第 10.1 节练习 7

## OT

### OLD
- A Stack, Two Queues
- Stack 实现的正确性

### NEW
- Stack 与 Queue 之间的互模拟 (TC 10.1-6, TC 10.1-7)
- TC Problem 10-3 (Searching a sorted compact list)