# README.md

## Homework

### OLD
- TC 第 13.1 节练习 5、7
- TC 第 13.2 节练习 2
- TC 第 13.3 节练习 1、5
- TC 第 13.4 节练习 1、7

### NEW
- TC 18.1-5
- TC 13.1-5、13.1-7
- TC 13.3-1、13.3-5
- TC 13.4-1、13.4-7

### Additional
- TC Problem 13-3: AVL trees

## OT

### OLD

### NEW